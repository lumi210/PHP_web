SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for __PREFIX__posters
-- ----------------------------
DROP TABLE IF EXISTS `__PREFIX__posters`;
CREATE TABLE `__PREFIX__posters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '标题',
  `config` text COLLATE utf8mb4_unicode_ci COMMENT '配置',
  `create_time` bigint(16) unsigned DEFAULT NULL COMMENT '创建时间',
  `update_time` bigint(16) unsigned DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='海报';

-- ----------------------------
-- Table structure for __PREFIX__posters
-- ----------------------------
INSERT INTO `__PREFIX__posters` (`id`, `title`, `config`, `create_time`, `update_time`) VALUES (1, '测试海报', '{\"poster_width\":\"422\",\"poster_height\":\"750\",\"poster_background_color\":\"rgba(216, 230, 254, 1)\",\"poster_background_image\":\"\",\"components\":[{\"type\":\"qr\",\"generate\":\"1\",\"zIndex\":\"1\",\"config\":{\"text\":\"http:\\/\\/badoucms.com?sp_uid={:sp_uid}\",\"left\":\"122\",\"top\":\"289\",\"width\":\"200\",\"height\":\"200\",\"margin\":\"1\",\"opacity\":\"100\"},\"value_type\":\"custom\"},{\"type\":\"text\",\"generate\":\"0\",\"zIndex\":\"2\",\"value_type\":\"custom\",\"config\":{\"text\":\"测试海报\",\"left\":\"117\",\"top\":\"194\",\"width\":\"205\",\"height\":\"95\",\"fontSize\":\"48\",\"color\":\"rgba(0, 19, 218, 1)\"}},{\"type\":\"text\",\"generate\":\"0\",\"zIndex\":\"3\",\"value_type\":\"custom\",\"config\":{\"text\":\"推荐好友得红包\",\"left\":\"141\",\"top\":\"523\",\"width\":\"157\",\"height\":\"51\",\"fontSize\":\"20\",\"color\":\"rgba(252, 31, 90, 1)\"}},{\"type\":\"text\",\"generate\":\"0\",\"zIndex\":\"4\",\"value_type\":\"custom\",\"config\":{\"text\":\"活动时间：xx年xx月xx日~xx年xx月xx日\",\"left\":\"58\",\"top\":\"618\",\"width\":\"323\",\"height\":\"26\",\"fontSize\":\"18\",\"color\":\"rgba(20, 20, 20, 1)\"}}]}', 1741222148, 1741571311);