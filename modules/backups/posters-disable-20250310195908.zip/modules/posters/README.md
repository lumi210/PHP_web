# 海报生成模块

基于 ThinkPHP8 + Vue3 的海报生成模块，支持多种组件和输出格式。

## 主要特性

- 支持背景图片或纯色背景
- 支持文字、图片、二维码组件
- 支持圆角图片处理
- 支持多种输出格式
- 支持图片尺寸调整
- 支持用户头像和昵称自动获取

## 使用方法

### 1. 事件调用

```php
use think\facade\Event;

$params = [
    'id' => 2,                    // 海报ID
    'output' => 'download',       // 输出方式：download|stream|base64|blob
    'size' => 1,               // 可选：图片缩放比例
    'qr_0' => [                  // 动态参数示例
        'sp_uid' => 1
    ]
];

try {
    return Event::trigger('poster.create', $params, true);
} catch (Exception $e) {
    // 错误处理
}
```

### 2、API 调用

```js
import createAxios from "/@/utils/axios";
const params = {
  id: 2,
  output: "download",
  size: 1,
  qr_0: {
    sp_uid: 1,
  },
};

createAxios({
  url: "/api/poster/create",
  method: "get",
  params: params,
})
  .then((res) => {
    // 处理返回结果
  })
  .catch((error) => {
    // 错误处理
  });
```

### 参数说明

| 参数名    | 类型         | 必填 | 说明                    |
| --------- | ------------ | ---- | ----------------------- |
| id        | int          | 是   | 海报 ID                 |
| output    | string       | 否   | 输出格式，默认 download |
| size      | float        | 否   | 缩放比例，默认 1        |
| qr\_\*    | array        | 否   | 二维码参数              |
| text\_\*  | array/string | 否   | 文本参数                |
| image\_\* | string       | 否   | 图片路径                |

### 输出格式

支持以下四种输出格式：

- `download` : 直接下载文件
- `stream` : 输出图片流，可直接显示
- `base64` : 返回 base64 编码
- `blob` : 返回二进制流

## 注意事项

1. 使用头像或昵称组件时需要用户登录
2. 图片支持本地路径和 HTTP 链接
3. 文本支持变量替换，格式： {:变量名}
4. 建议使用 try-catch 处理异常

## 常见问题

1. 图片不显示

   - 检查图片路径是否正确
   - 确认图片格式是否支持

2. 参数错误
   - 检查参数格式是否正确
