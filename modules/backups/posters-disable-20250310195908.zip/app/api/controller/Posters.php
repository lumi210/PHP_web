<?php

namespace app\api\controller;

use Exception;
use think\facade\Event;
use app\common\controller\Frontend;

class Posters extends Frontend
{
    protected array $noNeedLogin = ['*'];
    /**
     * 生成海报
     * @param int $id 海报id 必须传入
     * @return mixed
     */
    public function create()
    {
        $params = $this->request->param();
        $params['id'] = 1;
        $params['qr_0'] = ['sp_uid' => 1];
        try {
            return Event::trigger('poster.create', $params, true);
        } catch (Exception $e) {
            $this->error($e->getMessage());
        }
    }
}
