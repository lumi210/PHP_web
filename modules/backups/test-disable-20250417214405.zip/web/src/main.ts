import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import { loadLang } from '/@/lang/index'
import { registerIcons } from '/@/utils/common'
import ElementPlus from 'element-plus'
import mitt from 'mitt'
import pinia from '/@/stores/index'
import { directives } from '/@/utils/directives'
import 'element-plus/dist/index.css'
import 'element-plus/theme-chalk/display.css'
import 'font-awesome/css/font-awesome.min.css'
import '/@/styles/index.scss'
import '/@/styles/badou.scss'
import AddonsLoader from './utils/addonsLoader'

async function start() {
    const app = createApp(App)
    app.use(pinia)

    // 全局语言包加载
    await loadLang(app)

    app.use(router)
    app.use(ElementPlus)

    // 全局注册
    directives(app) // 指令
    registerIcons(app) // icons

    const addonsLoader = new AddonsLoader(app, router, pinia)
    // 将模块加载器挂载到全局，方便访问
    app.config.globalProperties.$addonsLoader = addonsLoader
    app.provide('addonsLoader', addonsLoader)
    app.mount('#app')
    // 初始化模块加载器

    // modules start mark, Please do not remove.
    console.log('main.ts start 1') // Code from module 'ueditorplus'(mts)
    console.log('main.ts start 1') // Code from module 'cmsskin'(mts)
    app.config.globalProperties.eventBus = mitt()
}
start()
